VIEWSHED_LABEL = {
    "coordinates": 'coordinates',
    "distance": 'distance',
    "height": 'height'
}
